import requests
from bs4 import BeautifulSoup

def scrape_website():
    url = "https://www.sbs.gob.pe/app/pp/sistip_portal/paginas/publicacion/tipocambiopromedio.aspx"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Identificar la tabla por su clase
    table = soup.find('table', class_='rgMasterTable')
    
    # Extraer todas las filas
    rows = table.findAll('tr')
    
    data = []
    for row in rows[1:]:  # Ignorar la fila de encabezado
        columns = row.findAll('td')
        moneda = columns[0].get_text().strip()
        compra = columns[1].get_text().strip()
        venta = columns[2].get_text().strip()
        
        data.append((moneda, compra, venta))
    
    return data

# Ejemplo para probar la función
data = scrape_website()
for row in data:
    print(row)


#def save_to_rds(data):
    # Asegúrate de modificar estos valores con tu información de conexión a RDS
 #   connection = pymssql.connect(host='database-1.cyi7vwwfc7zo.us-east-1.rds.amazonaws.com',
  #                               user='admin',
   #                              password='Admin12345',
    #                             database='Workshop')
    #try:
     #   with connection.cursor() as cursor:
      #      sql = "INSERT INTO tipo_cambio (moneda, compra, venta) VALUES (%s, %s, %s)"
       #     # Inserta cada fila de datos
        #    cursor.executemany(sql, data)
        # Commit the transaction
        #connection.commit()
    #finally:
        # Asegúrese de cerrar la conexión a la base de datos
     #   connection.close()#

def lambda_handler(event, context):
 data = scrape_website()  # Asegúrese de que la función scrape_website esté definida y disponible
 #save_to_rds(data)